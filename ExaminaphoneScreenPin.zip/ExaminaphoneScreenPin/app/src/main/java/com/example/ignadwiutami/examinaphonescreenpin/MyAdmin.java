package com.example.ignadwiutami.examinaphonescreenpin;
package wenchao.kiosk;

import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.app.admin.DeviceAdminReceiver;
import android.widget.Toast;


public class MyAdmin extends DeviceAdminReceiver{

    }
